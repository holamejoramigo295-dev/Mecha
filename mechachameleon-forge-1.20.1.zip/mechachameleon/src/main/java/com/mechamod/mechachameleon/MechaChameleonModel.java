package com.mechamod.mechachameleon;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class MechaChameleonModel extends EntityModel<MechaChameleonEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(MechaChameleonMod.MODID, "mecha_chameleon"), "main");

    private final ModelPart root;
    private final ModelPart head, eyeL, eyeR, tail, tail2, tail3;
    private final ModelPart legFR, legFL, legBR, legBL;

    public MechaChameleonModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.eyeL = head.getChild("eyeL");
        this.eyeR = head.getChild("eyeR");
        this.tail = root.getChild("tail");
        this.tail2 = tail.getChild("tail2");
        this.tail3 = tail2.getChild("tail3");
        this.legFR = root.getChild("legFR");
        this.legFL = root.getChild("legFL");
        this.legBR = root.getChild("legBR");
        this.legBL = root.getChild("legBL");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -4F, -7F, 8F, 8F, 14F),
                PartPose.offset(0F, 15F, 0F));
        // Cañón en el lomo
        body.addOrReplaceChild("cannon",
                CubeListBuilder.create().texOffs(0, 36).addBox(-1.5F, -7F, -4F, 3F, 3F, 8F),
                PartPose.ZERO);

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 24).addBox(-3.5F, -3F, -6F, 7F, 6F, 6F),
                PartPose.offset(0F, 13F, -7F));
        head.addOrReplaceChild("eyeL",
                CubeListBuilder.create().texOffs(28, 24).addBox(-1F, -1F, -1.5F, 2F, 2F, 3F),
                PartPose.offset(2.5F, -3.5F, -4.5F));
        head.addOrReplaceChild("eyeR",
                CubeListBuilder.create().texOffs(28, 24).addBox(-1F, -1F, -1.5F, 2F, 2F, 3F),
                PartPose.offset(-2.5F, -3.5F, -4.5F));

        PartDefinition tail = root.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(0, 48).addBox(-1.5F, -1.5F, 0F, 3F, 3F, 6F),
                PartPose.offset(0F, 15F, 7F));
        PartDefinition tail2 = tail.addOrReplaceChild("tail2",
                CubeListBuilder.create().texOffs(20, 48).addBox(-1F, -1F, 0F, 2F, 2F, 5F),
                PartPose.offset(0F, 0F, 6F));
        tail2.addOrReplaceChild("tail3",
                CubeListBuilder.create().texOffs(36, 48).addBox(-1F, -4F, 0F, 2F, 4F, 2F),
                PartPose.offset(0F, 0F, 5F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(48, 0).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F);
        root.addOrReplaceChild("legFR", leg, PartPose.offset(-4.5F, 19F, -4F));
        root.addOrReplaceChild("legFL", leg, PartPose.offset(4.5F, 19F, -4F));
        root.addOrReplaceChild("legBR", leg, PartPose.offset(-4.5F, 19F, 4F));
        root.addOrReplaceChild("legBL", leg, PartPose.offset(4.5F, 19F, 4F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(MechaChameleonEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);

        // Ojos giratorios independientes
        this.eyeL.yRot = Mth.cos(ageInTicks * 0.07F) * 0.6F;
        this.eyeR.yRot = Mth.sin(ageInTicks * 0.05F) * 0.6F;

        // Patas en diagonal
        float a = Mth.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        float b = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.2F * limbSwingAmount;
        this.legFR.xRot = a;
        this.legBL.xRot = a;
        this.legFL.xRot = b;
        this.legBR.xRot = b;

        // Cola ondulante
        this.tail.yRot = Mth.cos(ageInTicks * 0.1F) * 0.25F;
        this.tail2.yRot = Mth.cos(ageInTicks * 0.1F - 0.8F) * 0.3F;
        this.tail3.xRot = 0.4F + Mth.sin(ageInTicks * 0.08F) * 0.1F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
