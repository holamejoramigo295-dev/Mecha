package com.mechamod.mechachameleon;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MechaChameleonMod.MODID);

    public static final RegistryObject<EntityType<MechaChameleonEntity>> MECHA_CHAMELEON =
            ENTITIES.register("mecha_chameleon", () ->
                    EntityType.Builder.of(MechaChameleonEntity::new, MobCategory.MONSTER)
                            .sized(0.9F, 1.1F)
                            .clientTrackingRange(8)
                            .build("mecha_chameleon"));
}
