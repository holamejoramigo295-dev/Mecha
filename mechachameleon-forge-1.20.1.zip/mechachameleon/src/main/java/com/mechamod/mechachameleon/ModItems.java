package com.mechamod.mechachameleon;

import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MechaChameleonMod.MODID);

    public static final RegistryObject<Item> MECHA_CHAMELEON_SPAWN_EGG =
            ITEMS.register("mecha_chameleon_spawn_egg", () ->
                    new ForgeSpawnEggItem(ModEntities.MECHA_CHAMELEON, 0x4C8F5A, 0x2B2B2B, new Item.Properties()));
}
