package com.mechamod.mechachameleon;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MechaChameleonRenderer extends MobRenderer<MechaChameleonEntity, MechaChameleonModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(MechaChameleonMod.MODID, "textures/entity/mecha_chameleon.png");

    public MechaChameleonRenderer(EntityRendererProvider.Context context) {
        super(context, new MechaChameleonModel(context.bakeLayer(MechaChameleonModel.LAYER)), 0.6F);
    }

    @Override
    public ResourceLocation getTextureLocation(MechaChameleonEntity entity) {
        return TEXTURE;
    }
}
