# Mecha Chameleon (Forge 1.20.1)
Mod de Minecraft Java Forge 1.20.1 (47.3.0). Añade el **Mecha Camaleón**: un mob robótico que
se camufla (invisible, con chispas) mientras acecha y se revela a menos de 4 bloques o al recibir daño.
Su ataque deja Lentitud. Suelta hierro y redstone. Spawnea en el Overworld y tiene huevo generador.

Compilar: sube todo a GitHub; Actions > Build Mod > descarga el .jar de "Artifacts".
